# 📖 Manual de Instalación y Activación de Licencia · Quantum Trading System

Bienvenido a **Quantum Trading System v2.0**, la flota algorítmica coordinada para el par **XAUUSD (Oro)** en **MetaTrader 5**.

Este paquete incluye el **ejecutable binario cerrado y protegido**. No requiere compiladores, scripts complejos ni dependencias externas.

---

## ⚡ Inicio Rápido en 3 Pasos

### Paso 1: Configurar MetaTrader 5
1. Asegúrate de tener instalado **MetaTrader 5** en tu computadora con Windows.
2. Inicia sesión en tu cuenta de corretaje (demo o real, por ejemplo ICMarkets u otro broker con soporte para Oro).
3. Abre el gráfico de **XAUUSD** (Oro frente al Dólar).
4. En MetaTrader 5, ve a **Herramientas > Opciones > Asesores Expertos (Expert Advisors)** y marca la casilla **"Permitir trading algorítmico"** (Allow automated trading).

### Paso 2: Activar tu Clave de Licencia
1. Abre la carpeta del bot y haz doble clic en `start_quantum.bat`.
2. Se generará automáticamente el archivo `quantum_config.json` y se abrirá en el Bloc de Notas.
3. Rellena los siguientes campos:
   - `"license_key"`: Pega la clave alfanumérica recibida en tu correo tras la compra en Whop (ej. `QTM-QUAR-52984982-20261220-91A2687129954E6E`).
   - `"mt5_account"`: El número de tu cuenta de MetaTrader 5 vinculada a tu licencia.
   - `"risk_per_trade_pct"`: El porcentaje de riesgo máximo por operación (Recomendado: `1.0`% o `0.5`%).
   - `"mode"`: `"PAPER"` para operar en simulación interna o `"LIVE"` para colocar órdenes reales en tu cuenta.
4. Guarda el archivo (`Ctrl + G`) y cierra el Bloc de Notas.

### Paso 3: Lanzar la Flota
1. Presiona cualquier tecla en la ventana negra de la consola.
2. El sistema verificará tu firma criptográfica de licencia, se conectará a MetaTrader 5 y activará los 4 robots coordinados:
   - **Bot A (Alta Frecuencia / Momentum H1):** Magic `26082511`
   - **Bot B (Max Beneficio Tendencial):** Magic `26082512`
   - **Bot C (Sniper SMC & Sweeps):** Magic `26082513`
   - **Bot D (Escape Velocity & Estancamiento):** Magic `26082514`

---

## 🛡️ Preguntas Frecuentes y Soporte

* **¿Puedo compartir mi archivo con otra persona?**
  No. La licencia está firmada criptográficamente con el número de tu cuenta de corretaje (`MT5_LOGIN`). Si otra persona intenta usar tu ejecutable en otra cuenta, el sistema denegará la ejecución automáticamente.

* **¿Cómo cambio de cuenta demo a cuenta real?**
  Si adquiriste la **Licencia Vitalicia Enterprise ($99 USD)**, tu clave admite 2 cuentas simultáneas o comodín `ANY`. Solo cambia el número de cuenta en `quantum_config.json`. Si tienes la licencia trimestral, solicita la actualización gratuita de tu cuenta enviando tu comprobante a soporte.

* **Soporte y Consultas:**
  - Tienda Oficial: [Quantum Trading System](https://temporary-brisk-spruce-yx1bkmd.vercel.app/)
  - Telegram: [@sol2000_bot](https://t.me/sol2000_bot)
