@echo off
title Quantum Trading System - Multi-Bot Fleet v2.0
color 0A
echo =====================================================================
echo    QUANTUM TRADING SYSTEM - MULTI-BOT FLEET (XAUUSD/ORO)
echo    Ejecutable Binario Protegido - Licencia de Uso Autorizada
echo =====================================================================
echo.

if not exist quantum_config.json (
    echo [AVISO] Creando 'quantum_config.json' a partir del archivo de ejemplo...
    copy quantum_config.example.json quantum_config.json >nul
    echo.
    echo [IMPORTANTE] Abre 'quantum_config.json', coloca tu 'license_key'
    echo y tus datos de cuenta de MetaTrader 5 antes de continuar.
    echo.
    notepad quantum_config.json
    pause
)

echo [INFO] Iniciando motor algoritmico Quantum Fleet...
QuantumFleet_Runner.exe
pause
